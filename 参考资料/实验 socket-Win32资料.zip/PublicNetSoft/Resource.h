//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PublicNetSoft.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define WM_SERVER_ACCEPT                101
#define IDD_PUBLICNETSOFT_DIALOG        102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_LIST                        1000
#define IDC_SEND                        1001
#define IDC_EDIT                        1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
