#if !defined(AFX_LISTENINGSOCKET_H__F9CF1181_D008_11D4_8D3E_000E20004FF2__INCLUDED_)
#define AFX_LISTENINGSOCKET_H__F9CF1181_D008_11D4_8D3E_000E20004FF2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ListeningSocket.h : header file
//

class CCommView;

/////////////////////////////////////////////////////////////////////////////
// CListeningSocket command target

class CListeningSocket : public CSocket
{
// Attributes
public:
	CCommView* m_pView;
// Operations
public:
	CListeningSocket(CCommView* pView);
	virtual ~CListeningSocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListeningSocket)
	public:
	virtual void OnAccept(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CListeningSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LISTENINGSOCKET_H__F9CF1181_D008_11D4_8D3E_000E20004FF2__INCLUDED_)
