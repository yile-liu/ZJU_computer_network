#if !defined(AFX_COMMSOCKET_H__F9CF1182_D008_11D4_8D3E_000E20004FF2__INCLUDED_)
#define AFX_COMMSOCKET_H__F9CF1182_D008_11D4_8D3E_000E20004FF2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CommSocket.h : header file
//

class CCommView;

/////////////////////////////////////////////////////////////////////////////
// CCommSocket command target

class CCommSocket : public CSocket
{
// Attributes
public:
	CCommView* m_pView;
	CString m_strText;

// Operations
public:
	CCommSocket(CCommView* pView);
	virtual ~CCommSocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCommSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CCommSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COMMSOCKET_H__F9CF1182_D008_11D4_8D3E_000E20004FF2__INCLUDED_)
