// CommView.cpp : implementation of the CCommView class
//

#include "stdafx.h"
#include "Comm.h"

#include "CommDoc.h"
#include "CommView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "ListeningSocket.h"
#include "CommSocket.h"
#include "SendDlg.h"
/////////////////////////////////////////////////////////////////////////////
// CCommView

IMPLEMENT_DYNCREATE(CCommView, CEditView)

BEGIN_MESSAGE_MAP(CCommView, CEditView)
	//{{AFX_MSG_MAP(CCommView)
	ON_COMMAND(ID_SOCKET_SEND, OnSocketSend)
	ON_UPDATE_COMMAND_UI(ID_SOCKET_SEND, OnUpdateSocketSend)
	ON_COMMAND(ID_SOCKET_CLIENT, OnSocketClient)
	ON_UPDATE_COMMAND_UI(ID_SOCKET_CLIENT, OnUpdateSocketClient)
	ON_COMMAND(ID_SOCKET_SERVER, OnSocketServer)
	ON_UPDATE_COMMAND_UI(ID_SOCKET_SERVER, OnUpdateSocketServer)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCommView construction/destruction

CCommView::CCommView()
{
	// TODO: add construction code here
	iHostState=IDLE;
	m_pLstnSocket=NULL;
	iCommSocketNum=0;
	for (int iLoop=0;iLoop<MAXCOMMSOCKET;iLoop++)
		m_pCommSocket[iLoop]=NULL;
}

CCommView::~CCommView()
{
	if(m_pLstnSocket != NULL)
	{
		m_pLstnSocket->Close();
		delete m_pLstnSocket;
	}
}

BOOL CCommView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	BOOL bPreCreated = CEditView::PreCreateWindow(cs);
	cs.style &= ~(ES_AUTOHSCROLL|WS_HSCROLL);	// Enable word-wrapping

	return bPreCreated;
}

/////////////////////////////////////////////////////////////////////////////
// CCommView drawing

void CCommView::OnDraw(CDC* pDC)
{
	CCommDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CCommView printing

BOOL CCommView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default CEditView preparation
	return CEditView::OnPreparePrinting(pInfo);
}

void CCommView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView begin printing.
	CEditView::OnBeginPrinting(pDC, pInfo);
}

void CCommView::OnEndPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	// Default CEditView end printing
	CEditView::OnEndPrinting(pDC, pInfo);
}

/////////////////////////////////////////////////////////////////////////////
// CCommView diagnostics

#ifdef _DEBUG
void CCommView::AssertValid() const
{
	CEditView::AssertValid();
}

void CCommView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CCommDoc* CCommView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCommDoc)));
	return (CCommDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCommView message handlers

void CCommView::OnSocketServer() 
{
	// TODO: Add your command handler code here
	if(iHostState ==SERVER)  return;
	m_pLstnSocket=new CListeningSocket(this);
	if(m_pLstnSocket->Create(700))
	{
		if(m_pLstnSocket->Listen())
		{
			iHostState=SERVER;
		}
	}
}



void CCommView::OnUpdateSocketServer(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(iHostState==SERVER);
	pCmdUI->Enable(!(iHostState==CLIENT));
}

void CCommView::AcceptClientConnect()
{
	if(iCommSocketNum==MAXCOMMSOCKET)
	{
		AfxMessageBox((LPCTSTR)"Exceed Maximum socket connections.",MB_OK|MB_ICONSTOP);
		return;
	}
	int iLoop;
	for(iLoop=0;iLoop<MAXCOMMSOCKET;iLoop++)
		if(m_pCommSocket[iLoop]==NULL)  break;
	m_pCommSocket[iLoop]=new CCommSocket(this);
	if (!m_pLstnSocket->Accept(*m_pCommSocket[iLoop]))
	{
		AfxMessageBox((LPCTSTR)"Failed to create a comm socket.",MB_OK|MB_ICONSTOP);
		delete m_pCommSocket[iLoop];
		return;
	}
	iCommSocketNum++;
}

void CCommView::OnSocketClient() 
{
	// TODO: Add your command handler code here
	if (iHostState==CLIENT) return;
	if(ConnectSocket("10.14.11.196"))
	{
		AfxMessageBox("Connect socket succeeded.");
		iHostState=CLIENT;
		iCommSocketNum++;
	}
}

void CCommView::OnUpdateSocketClient(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(iHostState==CLIENT);
	pCmdUI->Enable(!(iHostState==SERVER));

}

BOOL CCommView::ConnectSocket(LPCTSTR lpszAddress)
{
	m_pCommSocket[0]=new CCommSocket(this);
	if(!m_pCommSocket[0]->Create())
	{
		AfxMessageBox((LPCTSTR)"Failed to create a socket!",MB_OK|MB_ICONSTOP);
		delete m_pCommSocket[0];
		m_pCommSocket[0]=NULL;
		return FALSE;
	}
	if(!m_pCommSocket[0]->Connect(lpszAddress,700))
	{
		AfxMessageBox((LPCTSTR)"Failed to connect to server!",MB_OK|MB_ICONSTOP);
		delete m_pCommSocket[0];
		m_pCommSocket[0]=NULL;
		return FALSE;
	}
	return TRUE;
}

void CCommView::OnSocketSend() 
{
	// TODO: Add your command handler code here
	CString strTmp;
	CSendDlg dlg;
	if(dlg.DoModal()==IDOK)
	{
		TRY
		{
			for(int iLoop=0;iLoop<MAXCOMMSOCKET;iLoop++)
			{
				if(m_pCommSocket[iLoop]!=NULL)
				{
					SendMsg(m_pCommSocket[iLoop],dlg.m_strSendText);
					if(strcmp(dlg.m_strSendText,"close")==0)
					{
						m_pCommSocket[iLoop]->ShutDown();
						m_pCommSocket[iLoop]->Close();
						delete m_pCommSocket[iLoop];
						m_pCommSocket[iLoop]=NULL;
						iCommSocketNum--;
						if (iHostState==CLIENT) iHostState=IDLE;
					}
				}
			}
			strTmp="Send:"+dlg.m_strSendText;
			ShowText(strTmp);
		}
		CATCH(CFileException,e)
		{
			AfxMessageBox("Send data exception!");
		}
		END_CATCH
	}
}

void CCommView::SendMsg(CCommSocket* pCommSocket,CString& strText)
{
	TRY { pCommSocket->Send(strText,strlen(strText)); }
	CATCH(CFileException,e)
	{
		AfxMessageBox("Send data exception!");
	}
	END_CATCH
}

void CCommView::OnUpdateSocketSend(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( (iHostState==SERVER) || (iHostState==CLIENT) );
}

void CCommView::ReceiveMsg(CCommSocket* pCommSocket)
{
	char strText[500],strTmp[500];
	int nRead;
	TRY
	{
		nRead=pCommSocket->Receive(strText,500);
		strText[nRead]=0;
		wsprintf(strTmp,"Recv:%s",strText);
		ShowText(strTmp);
		if(strcmp(strText,"close")==0)
		{
			ShowText("commsocket closed.");
			if(iHostState==CLIENT) iHostState=IDLE;
			for(int iLoop=0;iLoop<MAXCOMMSOCKET;iLoop++)
			{
				if(pCommSocket==m_pCommSocket[iLoop])
				{
					m_pCommSocket[iLoop]->ShutDown();
					m_pCommSocket[iLoop]->Close();
					delete m_pCommSocket[iLoop];
					m_pCommSocket[iLoop]=NULL;
					iCommSocketNum--;
					return;
				}
			}
		}
	}
	CATCH(CFileException,e)
	{
		AfxMessageBox("Receive data exception!");
	}
	END_CATCH
}

void CCommView::ShowText(LPCTSTR lpszText)
{
	CString strTemp=lpszText;
	strTemp+="\r\n";
	int iLen=GetWindowTextLength();
	GetEditCtrl().SetSel(iLen,iLen);
	GetEditCtrl().ReplaceSel(strTemp);
}
