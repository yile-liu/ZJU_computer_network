//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Comm.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_COMMTYPE                    129
#define IDD_SENDDLG                     130
#define IDC_EDSEND                      1000
#define ID_SOCKET_SERVER                32771
#define ID_SOCKET_CLIENT                32772
#define ID_SOCKET_SEND                  32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
